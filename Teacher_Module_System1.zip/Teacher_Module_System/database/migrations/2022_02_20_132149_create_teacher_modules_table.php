<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTeacherModulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teacher_modules', function (Blueprint $table) {
            $table->id();
            $table->string('lecturer_name');
            $table->string('gender');
            $table->integer('phone');
            $table->string('email_id');
            $table->string('address');
            $table->string('nationality');
            $table->string('dob');
            $table->integer('faculty_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teacher_modules');
    }
}
