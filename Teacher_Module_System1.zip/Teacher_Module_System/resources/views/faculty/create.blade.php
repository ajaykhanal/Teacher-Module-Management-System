@extends('base')
@section('title','Add Module')
@section('mainarea')
  <div class="container col-md-6 my-3">
     <h3>Add Module Page</h3><hr>
     <form method="POST" action="{{route('create_module_store')}}">
        @csrf
        <label>Lecturer's Name</label>
        <input type="text" class="form-control" name="lecturer_name">
        <span class="text-danger">@error('lecturer_name'){{$message}} @enderror</span><br>
        <label>Gender</label>
        <select class="form-control" name="gender">
            <option value="1">Male</option>
            <option value="2">Female</option>
            <option value="3">Others</option>
        </select>
        <span class="text-danger">@error('gender'){{$message}} @enderror</span><br>
        <label>Phone</label>
        <input type="number" class="form-control" name="phone">
        <span class="text-danger">@error('phone'){{$message}} @enderror</span><br>
        <label>Email Id</label>
        <input type="email" class="form-control" name="email">
        <span class="text-danger">@error('email'){{$message}} @enderror</span><br>
        <label>Address</label>
        <input type="text" class="form-control" name="address">
        <span class="text-danger">@error('address'){{$message}} @enderror</span><br>
        <label>Nationality</label>
        <input type="text" class="form-control" name="nationality">
        <span class="text-danger">@error('nationality'){{$message}} @enderror</span><br>
        <label>Date of Birth(DOB)</label>
        <input type="date" class="form-control" name="dob">
        <span class="text-danger">@error('dob'){{$message}} @enderror</span><br>
        <label>Faculty</label>
        <select class="form-control mb-1" name="faculty">
            @foreach($faculty as $fac)
            <option value="{{$fac->id}}">{{$fac->title}}</option>
            @endforeach
        </select>
        <span class="text-danger">@error('faculty'){{$message}} @enderror</span><br>
        <input type="submit" class="btn btn-success" value="Submit">
     </form>
  </div>
@endsection