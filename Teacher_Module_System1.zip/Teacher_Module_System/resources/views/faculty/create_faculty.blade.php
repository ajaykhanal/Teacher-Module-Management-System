@extends('base')
@section('title','Faculty')
@section('mainarea')
  <div class="container col-md-6">
     <h3>Create Faculty</h3><hr>
     <form method="POST" action="{{route('create_faculty')}}">
        @csrf
         <label>Faculty Name</label>
         <input type="text" class="form-control" name="title" >
         <span class="text-danger">@error('title'){{$message}} @enderror</span><br>
         <label>Detail</label>
         <textarea class="form-control" rows="4" cols="4" name="detail"></textarea>
         <span class="text-danger">@error('detail'){{$message}} @enderror</span><br>
         <input type="submit" class="btn btn-success" value="Create Faculty">
     </form>
  </div>
@endsection