<?php
    use App\Models\Faculty;
?>
@extends('base')
@section('title','Home')
@section('mainarea')
  <div class="container">
     <h1>Home Page</h1>
     <table class="table table-bordered table-hover">
        <thead>
              <tr>
                  <th>Lecturer Name</th>
                  <th>Gender</th>
                  <th>Phone</th>
                  <th>Email Id</th>
                  <th>Address</th>
                  <th>Nationality</th>
                  <th>Date of Birth</th>
                  <th>Faculty</th>
              </tr>
        </thead>
        <tbody>
            @foreach($data as $dat)
               <tr>
                   <td>{{$dat->lecturer_name}}</td>
                   <td>
                       @if($dat->gender == 1)
                            Male
                        @elseif($dat->gender == 2)
                            Female
                        @else
                            Others
                       @endif
                   </td>
                   <td>{{$dat->phone}}</td>
                   <td>{{$dat->email_id}}</td>
                   <td>{{$dat->address}}</td>
                   <td>{{$dat->nationality}}</td>
                   <td>{{$dat->dob}}</td>
                   <td>
                       <?php 
                            $faculty_id = Faculty::find($dat->faculty_id);
                        ?>
                        @if($faculty_id->id == 1)
                        Bsc Csit
                        @elseif($faculty_id->id == 4)
                        Education
                        @elseif($faculty_id->id == 5)
                        Bsc.Microbiology
                        @elseif($faculty_id->id == 6)
                        English
                        @endif
                   </td>
               </tr>
            @endforeach

        </tbody>
     </table>
     {{-- Pagination --}}
     <div class="d-flex justify-content-center">
        {!! $data->links() !!}
        
    </div>
    <a href="{{route('export')}}" class="btn btn-info">Export to CSV</a>
  </div>

@endsection

