$(function(){
    $("#export").click(function(id){
        $.ajax({
            type : 'GET',
            url: 'backup',
            success: function(data){
                console.log('Done');
            },
            error: function(data){
                console.log(data);
            }
        })
    })
})