<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Teacher_module;
use App\Exports\Teacher_modulesExport;
use Maatwebsite\Excel\Facades\Excel;

class CsvController extends Controller
{
    public function export() 
    {
        return Excel::download(new Teacher_modulesExport,'teachers_module.csv');
    }
}
 
?>
