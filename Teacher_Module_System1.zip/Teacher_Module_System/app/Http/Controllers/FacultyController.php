<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Faculty;
use App\Models\Teacher_module;

class FacultyController extends Controller
{
    public function index(){
        $data= Teacher_module::orderBy('id','desc')->paginate(3);
        return view('faculty.index',compact('data'));
    }

   
    public function create_faculty(){
        return view('faculty.create_faculty');
    }
    

    public function create_faculty_store(Request $request){
        $request->validate([
            'title'=>'required',
            'detail'=>'required',
        ]);
        $faculty= new Faculty;
        $faculty->title= $request->title;
        $faculty->detail= $request->detail;
        $faculty->save();
        return redirect()->route('home')->with('success',"Faculty has been created !!");
        // return view('faculty.create_faculty');
    }

    public function create_module(){
        $faculty= Faculty::all();
        return view('faculty.create',compact('faculty'));
    }

    public function create_module_store(Request $request){
        $request->validate([
            'lecturer_name'=>'required',
            'gender'=>'required',
            'phone'=>'required',
            'email'=>'required',
            'address'=>'required',
            'nationality'=>'required',
            'dob'=>'required',
            'faculty'=>'required',
        ]);
        $teacher_module= new Teacher_module;
        $teacher_module->lecturer_name= $request->lecturer_name;
        $teacher_module->gender= $request->gender;
        $teacher_module->phone= $request->phone;
        $teacher_module->email_id= $request->email;
        $teacher_module->address= $request->address;
        $teacher_module->nationality= $request->nationality;
        $teacher_module->dob= $request->dob;
        $teacher_module->faculty_id= $request->faculty;
        $teacher_module->save();
        return redirect()->route('home')->with('success','Teacher Module has been successfully created!!');
    }

    /* public function exportCsv(Request $request)
{
   $fileName = 'tasks.csv';
   $tasks = Teacher_module::all();

        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );

        $columns = array('lecturer_name', 'gender', 'phone', 'email_id', 'address','nationality','dob','faculty_id');

        $callback = function() use($tasks, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($tasks as $task) {
                $row['lecturer_name']  = $task->lecturer_name;
                $row['gender']    = $task->assign->gender;
                $row['phone']    = $task->phone;
                $row['email_id']  = $task->email_id;
                $row['address']  = $task->address;
                $row['nationality']  = $task->nationality;
                
                $row['dob']  = $task->dob;
                $row['faculty_id']  = $task->faculty_id;

                fputcsv($file, array($row['lecturer_name'], $row['gender'], $row['phone'], $row['email_id'], $row['address'],$row['nationality'],$row['dob'],$row['faculty_id']));
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    } */

    // public function backup(){
    //     //ENTER THE RELEVANT INFO BELOW
    //     $mysqlHostName      = env('127.0.0.1');
    //     $mysqlUserName      = env('root');
    //     $mysqlPassword      = env('');
    //     $DbName             = env('Teacher_Module');
    //     $backup_name        = "mybackup.sql";
    //     $tables             = array("users","messages","posts"); //here your tables...

    //     $connect = new \PDO("mysql:host=$mysqlHostName;dbname=$DbName;charset=utf8", "$mysqlUserName", "$mysqlPassword",array(\PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
    //     $get_all_table_query = "SHOW TABLES";
    //     $statement = $connect->prepare($get_all_table_query);
    //     $statement->execute();
    //     $result = $statement->fetchAll();


    //     $output = '';
    //     foreach($tables as $table)
    //     {
    //      $show_table_query = "SHOW CREATE TABLE " . $table . "";
    //      $statement = $connect->prepare($show_table_query);
    //      $statement->execute();
    //      $show_table_result = $statement->fetchAll();

    //      foreach($show_table_result as $show_table_row)
    //      {
    //       $output .= "\n\n" . $show_table_row["Create Table"] . ";\n\n";
    //      }
    //      $select_query = "SELECT * FROM " . $table . "";
    //      $statement = $connect->prepare($select_query);
    //      $statement->execute();
    //      $total_row = $statement->rowCount();

    //      for($count=0; $count<$total_row; $count++)
    //      {
    //       $single_result = $statement->fetch(\PDO::FETCH_ASSOC);
    //       $table_column_array = array_keys($single_result);
    //       $table_value_array = array_values($single_result);
    //       $output .= "\nINSERT INTO $table (";
    //       $output .= "" . implode(", ", $table_column_array) . ") VALUES (";
    //       $output .= "'" . implode("','", $table_value_array) . "');\n";
    //      }
    //     }
    //     $file_name = 'database_backup_on_' . date('y-m-d') . '.sql';
    //     $file_handle = fopen($file_name, 'w+');
    //     fwrite($file_handle, $output);
    //     fclose($file_handle);
    //     header('Content-Description: File Transfer');
    //     header('Content-Type: application/octet-stream');
    //     header('Content-Disposition: attachment; filename=' . basename($file_name));
    //     header('Content-Transfer-Encoding: binary');
    //     header('Expires: 0');
    //     header('Cache-Control: must-revalidate');
    //        header('Pragma: public');
    //        header('Content-Length: ' . filesize($file_name));
    //        ob_clean();
    //        flush();
    //        readfile($file_name);
    //        unlink($file_name);
    // }
}
