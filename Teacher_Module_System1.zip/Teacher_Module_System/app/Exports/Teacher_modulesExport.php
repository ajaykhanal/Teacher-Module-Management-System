<?php

namespace App\Exports;

use App\Models\Teacher_module;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithCustomCsvSettings;
use Maatwebsite\Excel\Concerns\WithHeadings;

class Teacher_modulesExport implements FromCollection, WithCustomCsvSettings, WithHeadings
{
    public function getCsvSettings(): array
    {
        return [
            'delimiter' => ','
        ];
    }

    public function headings(): array
    {
        return ['Lecturer_name','Gender','Phone','Email_id','Address','Nationality','Date of Birth','Faculty_Name'];
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Teacher_module::select('lecturer_name','gender','phone','email_id','address','nationality','dob','faculty_id')->get();
    }
} 
?>