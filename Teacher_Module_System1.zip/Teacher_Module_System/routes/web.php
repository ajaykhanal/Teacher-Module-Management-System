<?php

use App\Http\Controllers\FacultyController;
use App\Http\Controllers\CsvController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/',[FacultyController::class,'index'])->name('home');

Route::get('add',[FacultyController::class,'create_module'])->name('create');
Route::post('add',[FacultyController::class,'create_module_store'])->name('create_module_store');

Route::get('create/faculty',[FacultyController::class,'create_faculty'])->name('create_faculty');
Route::post('create/faculty',[FacultyController::class,'create_faculty_store'])->name('create_faculty_store');

// Route::get('/tasks',[FacultyController::class,'exportCsv'])->name('exportCsv');

// Route::get('backup',[FacultyController::class,'backup'])->name('backup');

Route::get('/export-csv', [CsvController::class,'export'])->name('export');
