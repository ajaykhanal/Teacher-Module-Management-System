<?php $__env->startSection('title','Faculty'); ?>
<?php $__env->startSection('mainarea'); ?>
  <div class="container col-md-6">
     <h3>Create Faculty</h3><hr>
     <form method="POST" action="<?php echo e(route('create_faculty')); ?>">
        <?php echo csrf_field(); ?>
         <label>Faculty Name</label>
         <input type="text" class="form-control" name="title" >
         <span class="text-danger"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
         <label>Detail</label>
         <textarea class="form-control" rows="4" cols="4" name="detail"></textarea>
         <span class="text-danger"><?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
         <input type="submit" class="btn btn-success" value="Create Faculty">
     </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ajay/Teacher_Module_System/resources/views/faculty/create_faculty.blade.php ENDPATH**/ ?>