<?php
    use App\Models\Faculty;
?>

<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('mainarea'); ?>
  <div class="container">
     <h1>Home Page</h1>
     <table class="table table-bordered table-hover">
        <thead>
              <tr>
                  <th>Lecturer Name</th>
                  <th>Gender</th>
                  <th>Phone</th>
                  <th>Email Id</th>
                  <th>Address</th>
                  <th>Nationality</th>
                  <th>Date of Birth</th>
                  <th>Faculty</th>
              </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                   <td><?php echo e($dat->lecturer_name); ?></td>
                   <td>
                       <?php if($dat->gender == 1): ?>
                            Male
                        <?php elseif($dat->gender == 2): ?>
                            Female
                        <?php else: ?>
                            Others
                       <?php endif; ?>
                   </td>
                   <td><?php echo e($dat->phone); ?></td>
                   <td><?php echo e($dat->email_id); ?></td>
                   <td><?php echo e($dat->address); ?></td>
                   <td><?php echo e($dat->nationality); ?></td>
                   <td><?php echo e($dat->dob); ?></td>
                   <td>
                       <?php 
                            $faculty_id = Faculty::find($dat->faculty_id);
                        ?>
                        <?php if($faculty_id->id == 1): ?>
                        Bsc Csit
                        <?php elseif($faculty_id->id == 4): ?>
                        Education
                        <?php elseif($faculty_id->id == 5): ?>
                        Bsc.Microbiology
                        <?php elseif($faculty_id->id == 6): ?>
                        English
                        <?php endif; ?>
                   </td>
               </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
     </table>
     
     <div class="d-flex justify-content-center">
        <?php echo $data->links(); ?>

        
    </div>
    <a href="<?php echo e(route('export')); ?>" class="btn btn-info">Export to CSV</a>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ajay/Teacher_Module_System/resources/views/faculty/index.blade.php ENDPATH**/ ?>